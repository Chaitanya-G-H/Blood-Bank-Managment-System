<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Exchange Blood Registration</title>
    <link rel="stylesheet" type="text/css" href="css/s1.css">
    <style type="text/css">
        #form1 {
            width: 90%;
            background-color: #cc0000;
            color: black;
            border-radius: 10px;
            padding: 20px;
            box-sizing: border-box;
        }
        table {
            width: 100%;
            margin: 10px 0;
            border-collapse: collapse;
        }
        td {
            padding: 10px;
            text-align: left;
            color: white;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], textarea, select {
            width: 90%;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        input[type="submit"] {
            padding: 10px 20px;
            background-color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            color: #cc0000;
            font-weight: bold;
        }
        input[type="submit"]:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
<div id="full">
    <div id="inner_full">
        <div id="header"><h2><a href="admin-home.php" style="text-decoration: none; color: black;">Blood Bank Management System</a></h2></div>
        <div id="body">
            <br>
            <?php
            $un = $_SESSION['un'];
            if (!$un) {
                header("Location:index.php");
            }
            ?>
            <h1>Exchange Blood Donor Registration</h1>
            <center>
                <div id="form1">
                    <form action="" method="post">
                        <table>
                            <tr>
                                <td>Enter Name</td>
                                <td><input type="text" name="name" placeholder="Enter Name" required></td>
                                <td>Enter Father's Name</td>
                                <td><input type="text" name="fname" placeholder="Enter Father's Name" required></td>
                            </tr>
                            <tr>
                                <td>Enter Address</td>
                                <td><textarea name="address" placeholder="Enter Address" required></textarea></td>
                                <td>Enter City</td>
                                <td><input type="text" name="city" placeholder="Enter City" required></td>
                            </tr>
                            <tr>
                                <td>Enter Age</td>
                                <td><input type="text" name="age" placeholder="Enter Age" required></td>
                                <td>Enter E-Mail</td>
                                <td><input type="email" name="email" placeholder="Enter E-Mail" required></td>
                            </tr>
                            <tr>
                                <td>Enter Mobile No</td>
                                <td><input type="text" name="mno" placeholder="Enter Mobile No" required></td>
                                <td>Your Blood Group</td>
                                <td>
                                    <select name="bgroup" required>
                                        <option>O+</option>
                                        <option>AB+</option>
                                        <option>AB-</option>
                                        <option>B+</option>
                                        <option>B-</option>
                                        <option>O-</option>
                                        <option>A+</option>
                                        <option>A-</option>
                                    </select>
                                </td> 
                            </tr>
                            <tr>
                                <td>Exchange Blood Group</td>
                                <td>
                                    <select name="exchange_bgroup" required>
                                        <option>O+</option>
                                        <option>AB+</option>
                                        <option>AB-</option>
                                        <option>B+</option>
                                        <option>B-</option>
                                        <option>O-</option>
                                        <option>A+</option>
                                        <option>A-</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" style="text-align: center;"><input type="submit" name="submit" value="Save"></td>
                            </tr>
                        </table>
                    </form>
                    <?php
                    if (isset($_POST['submit'])) {
                        $name = $_POST['name'];
                        $fname = $_POST['fname'];
                        $address = $_POST['address'];
                        $city = $_POST['city'];
                        $age = $_POST['age'];
                        $bgroup = $_POST['bgroup'];
                        $exchange_bgroup = $_POST['exchange_bgroup'];
                        $email = $_POST['email'];
                        $mno = $_POST['mno'];

                        // Check for existing donor with the same blood group
                        $q = "SELECT * FROM donor_registration WHERE bgroup = :bgroup LIMIT 1";
                        $st = $db->prepare($q);
                        $st->bindParam(':bgroup', $bgroup);
                        $st->execute();
                        $num_row = $st->fetch(PDO::FETCH_ASSOC);

                        if ($num_row) {
                            $id = $num_row['id'];
                            $b1 = $num_row['bgroup'];
                            $name1 = $num_row['name'];
                            $mno1 = $num_row['mno'];

                            // Insert into out_stock_b
                            $q2 = "INSERT INTO out_stock_b (bgroup, name, mno) VALUES (?, ?, ?)";
                            $st1 = $db->prepare($q2);
                            $st1->execute([$b1, $name1, $mno1]);

                            // Delete from donor_registration
                            $delete_q = "DELETE FROM donor_registration WHERE id = :id";
                            $st2 = $db->prepare($delete_q);
                            $st2->bindParam(':id', $id);
                            $st2->execute();
                        }

                        // Insert the new donor's information into donor_registration
                        $q = $db->prepare("INSERT INTO donor_registration(name, fname, address, city, age, bgroup, exchange_bgroup, email, mno) VALUES (:name, :fname, :address, :city, :age, :bgroup, :exchange_bgroup, :email, :mno)");
                        $q->bindParam(':name', $name);
                        $q->bindParam(':fname', $fname);
                        $q->bindParam(':address', $address);
                        $q->bindParam(':city', $city);
                        $q->bindParam(':age', $age);
                        $q->bindParam(':bgroup', $bgroup);
                        $q->bindParam(':exchange_bgroup', $exchange_bgroup);
                        $q->bindParam(':email', $email);
                        $q->bindParam(':mno', $mno);

                        if ($q->execute()) {
                            echo "<script>alert('Donor Registration Successful')</script>";
                        } else {
                            echo "<script>alert('Donor Registration Failed')</script>";
                        }
                    }
                    ?>
                </div>
            </center>
        </div>
        <div id="footer"><h4 align="center">© myprojecthd</h4>
            <p align="center"><a href="logout.php"><font color="black">Logout</font></a></p>
        </div>
    </div>
</div>   
</body>
</html>

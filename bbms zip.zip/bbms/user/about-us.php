<!DOCTYPE html>
<html>
<head>
    <title>Blood Bank Home</title>
    <link rel="stylesheet" type="text/css" href="css/style1.css">
</head>
<body>
    <div class="header">
        <div class="logo">
            <h1 align="center">Blood Bank Management System</h1>
        </div>
        <div class="nav">
            <div id="a"><a href="home.php"><h1>Home</h1></a></div>
            <div id="b"><a href="about-us.php"><h1>About Us</h1></a></div>
            <div id="c"><a href="contact-us.php"><h1>Contact Us</h1></a></div>
            <div id="d"><a href="login.php"><h1>Login</h1></a></div>
        </div>
    </div>
    <div class="banner">
        <h1 align="center" style="color: black;">Online Blood Bank</h1>
    </div>  

    <div class="container">
        <br>
        <h2 align="center" style="color: red;">About Us</h2>
        <br><br>
<p>Welcome to the *Online Blood Bank Management System*—where compassion and innovation save lives. We’re on a mission to revolutionize the way people donate and receive blood, ensuring that life-saving resources are just a click away for those who need them most.

Our cutting-edge platform brings together donors, blood banks, and hospitals, making it quick and easy to find, donate, or request blood. Driven by a commitment to community health, we promote safe, convenient donations and smart inventory management.

*Be a hero*—join us in the fight against blood shortages. With your help, every drop has the power to change a life. Together, we can make every donation count!</p>
    </div>

    <div class="footer">
        <h2 align="center">Copyright © myprojecthd</h2>
    </div>
</body>
</html>

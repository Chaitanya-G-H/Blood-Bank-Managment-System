<?php
header("Location:../");
?>
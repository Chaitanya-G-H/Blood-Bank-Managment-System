<!DOCTYPE html>
<html>
<head>
    <title>Blood Bank About</title>
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <style>
        /* Flex container for content */
        .container {
            display: flex;
            padding: 20px;
            gap: 20px;
        }

        /* Styling for the address section */
        #address {
            width: 50%;
            padding: 20px;
            line-height: 1.6;
        }

        /* Footer styling */
        .footer {
            background-color: red;
            color: black;
            padding: 20px 0;
            text-align: center;
        }

        /* Header and navigation styling */
        .header {
            background-color: red;
            color: black;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo h2 {
            margin: 0;
        }

        .nav div {
            margin: 0 10px;
            display: inline-block;
        }

        .nav a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            padding: 8px;
        }

        .nav a:hover {
            background-color: darkred;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<div class="header">
    <div class="logo">
        <h2>Blood Bank Management System</h2>
    </div>
    <div class="nav">
        <div id="a"><a href="index.php">Home</a></div>
        <div id="b"><a href="about.php">About Us</a></div>
        <div id="c"><a href="contact-us.php">Contact Us</a></div>
        <div id="d"><a href="login.php">Login</a></div>
    </div>
</div>

<div class="banner">
    <h1 align="center" style="color: black; padding: 100px 0;">Online Blood Bank</h1>
</div>

<div class="container">
    <div id="address">
        <h1>Contact Blood Bank</h1>
        <h2><p><b>Address:</b>No.123/B MNC Locality,1st B cross,Rajajinagar</p></h2>
        <h2><p><b>Mobile No:</b>9964498026 </p></h2>
        <h2><p><b>Email:</b> bloodbank@gmail.com </p></h2>
    </div>
</div>

<div class="footer">
    <h2>Copyright @myprojecthd</h2>
</div>

</body>
</html>


<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Exchange Blood List</title>
    <link rel="stylesheet" type="text/css" href="css/s1.css">
    <style type="text/css">
        body {
            background-color: lightgray; /* Light background color */
            font-family: Arial, sans-serif;
        }
        #full {
            width: 80%;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        #header, #footer {
            background-color: #d32f2f; /* Dark red */
            color: white;
            text-align: center;
            padding: 10px;
            border-radius: 8px;
        }
        #body {
            padding: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        td, th {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #d32f2f;
            color: white;
        }
        td {
            color: #333;
        }
        a {
            color: black;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div id="full">
    <div id="inner_full">
        <div id="header"><h2><a href="admin-home.php">Blood Bank Management System</a></h2></div>
        <div id="body">
            <h1>Exchange Blood List</h1>
            <?php
            $un = $_SESSION['un'];
            if (!$un) {
                header("Location:index.php");
            }
            ?>
            <center>
                <div id="form">
                    <table>
                        <tr>
                            <th>Exchange Blood Group</th>
                            <th>Quantity</th>
                        </tr>
                        <tr>
                            <td>O+</td>
                            <td>
                                <?php
                                $q = $db->query("SELECT * FROM donor_registration WHERE exchange_bgroup='O+'");
                                echo $q->rowCount();
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>AB+</td>
                            <td>
                                <?php
                                $q = $db->query("SELECT * FROM donor_registration WHERE exchange_bgroup='AB+'");
                                echo $q->rowCount();
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>AB-</td>
                            <td>
                                <?php
                                $q = $db->query("SELECT * FROM donor_registration WHERE exchange_bgroup='AB-'");
                                echo $q->rowCount();
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>B+</td>
                            <td>
                                <?php
                                $q = $db->query("SELECT * FROM donor_registration WHERE exchange_bgroup='B+'");
                                echo $q->rowCount();
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>B-</td>
                            <td>
                                <?php
                                $q = $db->query("SELECT * FROM donor_registration WHERE exchange_bgroup='B-'");
                                echo $q->rowCount();
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>O-</td>
                            <td>
                                <?php
                                $q = $db->query("SELECT * FROM donor_registration WHERE exchange_bgroup='O-'");
                                echo $q->rowCount();
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>A+</td>
                            <td>
                                <?php
                                $q = $db->query("SELECT * FROM donor_registration WHERE exchange_bgroup='A+'");
                                echo $q->rowCount();
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>A-</td>
                            <td>
                                <?php
                                $q = $db->query("SELECT * FROM donor_registration WHERE exchange_bgroup='A-'");
                                echo $q->rowCount();
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </center>
        </div>
        <div id="footer">
            <h4>© myprojecthd</h4>
            <p><a href="logout.php">Logout</a></p>
        </div>
    </div>
</div>
</body>
</html>
<?php
include('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Sign Up</title>
    <link rel="stylesheet" type="text/css" href="css/s1.css">
</head>
<body>
<div id="full">
    <div id="inner_full">
        <div id="header"><h2>Blood Bank Management System - Sign Up</h2></div>
        <div id="body">
            <br><br><br><br><br>
            <form action="" method="post">
                <table align="center">
                    <tr>
                        <td width="200px" height="70px"><b>Enter Username</b></td>
                        <td width="100px" height="70px">
                            <input type="text" name="un" placeholder="Enter Username" style="width: 180px; height: 30px; border-radius: 10px;" required>
                        </td>
                    </tr>
                    <tr>
                        <td width="200px" height="70px"><b>Enter Password</b></td>
                        <td width="200px" height="70px">
                            <input type="password" name="ps" placeholder="Enter Password" style="width: 180px; height: 30px; border-radius: 10px;" required>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center">
                            <input type="submit" name="register" value="Sign Up" style="width: 70px; height: 30px; border-radius: 5px;">
                        </td>
                    </tr>
                </table>
            </form>
            <?php
            if (isset($_POST['register'])) {
                $un = $_POST['un'];
                $ps = $_POST['ps'];
                
                // Check if the username already exists
                $check = $db->prepare("SELECT * FROM admin WHERE uname = :uname");
                $check->execute(['uname' => $un]);
                
                if ($check->rowCount() > 0) {
                    echo "<script>alert('Username already exists');</script>";
                } else {
                    // Insert new user into the database
                    $q = $db->prepare("INSERT INTO admin (uname, pass) VALUES (:uname, :pass)");
                    $q->execute(['uname' => $un, 'pass' => $ps]);
                    echo "<script>alert('Registration successful!'); window.location.href = 'index.php';</script>";
                }
            }
            ?>
        </div>
        <div id="footer">
            <h4 align="center">&copy; myprojecthd</h4>
        </div>
    </div>
</div>
</body>
</html>
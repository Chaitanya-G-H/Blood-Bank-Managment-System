<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="css/s1.css">
</head>
<body>
<div id="full">
    <div id="inner_full">
        <div id="header"><h2>Blood Bank Management System</h2></div>
        <div id="body">
            <br><br><br><br><br>
            <form action="" method="post">
                <table align="center">
                    <tr>
                        <td width="200px" height="70px"><b>Enter Username</b></td>
                        <td width="100px" height="70px">
                            <input type="text" name="un" placeholder="Enter Username" style="width: 180px; height: 30px; border-radius: 10px;">
                        </td>
                    </tr>
                    <tr>
                        <td width="200px" height="70px"><b>Enter Password</b></td>
                        <td width="200px" height="70px">
                            <input type="password" name="ps" placeholder="Enter Password" style="width: 180px; height: 30px; border-radius: 10px;">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center">
                            <input type="submit" name="sub" value="Login" style="width: 70px; height: 30px; border-radius: 5px;">
                        </td>
                    </tr>
                    <tr>
                        <?php
                            if(isset($_POST['signup'])) {
                                header("location: register.php");
                            } 
                        ?>
                        <td colspan="2" align="center">
                            <input type="submit" name="signup" value="Sign Up" style="width: 70px; height: 30px; border-radius: 5px;">
                        </td>
                    </tr>
                </table>
            </form>
            <?php
            if (isset($_POST['sub'])) {
                $un = $_POST['un'];
                $ps = $_POST['ps'];
                
                // Secure query to prevent SQL injection
                $q = $db->prepare("SELECT * FROM admin WHERE uname = :uname AND pass = :pass");
                $q->execute(['uname' => $un, 'pass' => $ps]);
                $res = $q->fetchAll(PDO::FETCH_OBJ);

                if ($res) {
                    $_SESSION['un'] = $un;
                    header("Location: admin-home.php");
                    exit();
                } else {
                    echo "<script>alert('Incorrect Username or Password');</script>";
                }
            }
            ?>
        </div>
        <div id="footer">
            <h4 align="center">&copy; myprojecthd</h4>
        </div>
    </div>
</div>
</body>
</html>
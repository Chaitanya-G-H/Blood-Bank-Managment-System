<!DOCTYPE html>
<html>
<head>
    <title>Blood Bank Home</title>
    <link rel="stylesheet" type="text/css" href="css/style1.css">
</head>
<body>
    <div class="header">
        <div class="logo">
            <h1 align="center">Blood Bank Management System</h1>
        </div>
        <div class="nav">
            <div id="a"><a href="home.php"><h2>Home</h2></a></div>
            <div id="b"><a href="about-us.php"><h2>About Us</h2></a></div>
            <div id="c"><a href="contact-us.php"><h2>Contact Us</h2></a></div>
            <div id="d"><a href="login.php"><h2>Login</h2></a></div>
        </div>
    </div>
    <div class="banner">
        <h1 align="center" style="color: black;">Online Blood Bank</h1>
    </div>  

    <div class="container">
        <br>
        <h2 align="center" style="color: red;">Doctor's Information</h2>
        <br><br>
        <center>
            <table border="1px">
                <tr>
                    <td width="200px" height="50px" style="color: red;"><center><b>Doctor Name</b></center></td> 
                    <td width="200px" height="50px" style="color: red;"><center><b>Mobile No.</b></center></td>
                    <td width="200px" height="50px" style="color: red;"><center><b>Address</b></center></td>
                    <td width="200px" height="50px" style="color: red;"><center><b>Specialization</b></center></td>
                </tr> 
                <tr>
                    <td width="200px" height="50px"><center>Demo Name</center></td> 
                    <td width="200px" height="50px"><center>433535353654</center></td>
                    <td width="200px" height="50px"><center>xyz</center></td>
                    <td width="200px" height="50px"><center>General Medicine</center></td>
                </tr>
            </table>
        </center>
    </div>

    <div class="footer">
        <h2 align="center">Copyright © myprojecthd</h2>
    </div>
</body>
</html>
